package com.mohit.dualtts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;

// Invisible activity: Settings asks "what sample sentence should I speak for
// this language?" when the user taps "Listen to an example".
public class GetSampleText extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String language = getIntent() != null ? getIntent().getStringExtra("language") : null;
        String text;
        if (language != null && (language.startsWith("hi"))) {
            text = "यह पॉकेट ड्युअल टीटीएस का हिंदी नमूना है।";
        } else {
            text = "This is a sample of Pocket Dual TTS.";
        }
        Intent result = new Intent();
        result.putExtra("sampleText", text);
        setResult(TextToSpeech.LANG_AVAILABLE, result);
        finish();
    }
}
