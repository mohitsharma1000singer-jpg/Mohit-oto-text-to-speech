package com.mohit.dualtts;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String FALLBACK_ENGINE = "com.google.android.tts";
    private static final float[] SPEEDS = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f};
    private static final float[] PITCHES = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
    private static final float[] VOLUMES = {0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 2.5f, 3f};

    private static class VoiceItem {
        String name;   // "" = engine's default voice for that language
        String tag;    // language tag of the voice, e.g. en-US
        String label;
    }

    private static class EngineItem {
        String pkg;
        String label;
        Map<String, List<VoiceItem>> byLang = new HashMap<>();
    }

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView statusText;
    private Spinner languageSpinner, engineSpinner, voiceSpinner, speedSpinner, pitchSpinner, volumeSpinner;
    private CheckBox boostBox;
    private EditText inputText;

    private final List<EngineItem> engines = new ArrayList<>();
    private final List<TextToSpeech> probes = new ArrayList<>();
    private int pendingProbes = 0;
    private boolean scanFinished = false;

    private final List<String> availKeys = new ArrayList<>();
    private List<EngineItem> curEngines = new ArrayList<>();
    private List<VoiceItem> curVoices = new ArrayList<>();
    private String curKey = null;
    private int curLangIdx = -1, curEngineIdx = -1, curVoiceIdx = -1;
    private int curSpeedIdx = -1, curPitchIdx = -1, curVolumeIdx = -1;

    private TextToSpeech testTts;
    private boolean testReady = false;
    private String pendingTestText = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("dual_tts_prefs", MODE_PRIVATE);
        buildUi();
        startScan();
    }

    // ------------------------------------------------------------ UI
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        statusText = new TextView(this);
        statusText.setTextSize(16);
        statusText.setText("इंजन स्कैन हो रहे हैं, कृपया प्रतीक्षा करें...");
        root.addView(statusText);

        languageSpinner = addSpinner(root, "भाषा चुनें");
        engineSpinner = addSpinner(root, "इंजन चुनें");
        voiceSpinner = addSpinner(root, "वॉइस चुनें");
        pitchSpinner = addSpinner(root, "पिच");
        speedSpinner = addSpinner(root, "गति (स्पीड)");
        volumeSpinner = addSpinner(root, "वॉल्यूम");

        boostBox = new CheckBox(this);
        boostBox.setText("ओवरराइड वॉल्यूम: आवाज़ बहुत ज़्यादा तेज़ करें (क्वालिटी कम हो सकती है)");
        root.addView(boostBox);

        TextView testLabel = new TextView(this);
        testLabel.setText("टेस्ट करें");
        testLabel.setTextSize(16);
        testLabel.setTypeface(null, Typeface.BOLD);
        testLabel.setPadding(0, pad, 0, 0);
        root.addView(testLabel);

        inputText = new EditText(this);
        inputText.setHint("यहाँ हिंदी और English मिला हुआ टेक्स्ट लिखें");
        root.addView(inputText);

        Button speakButton = new Button(this);
        speakButton.setText("बोलें");
        speakButton.setOnClickListener(v -> speakTest());
        root.addView(speakButton);

        Button stopButton = new Button(this);
        stopButton.setText("रोकें");
        stopButton.setOnClickListener(v -> {
            if (testTts != null) testTts.stop();
        });
        root.addView(stopButton);

        setContentView(scroll);

        languageSpinner.setOnItemSelectedListener(new Sel() {
            @Override void changed(int pos) {
                if (pos == curLangIdx || pos < 0 || pos >= availKeys.size()) return;
                curLangIdx = pos;
                prefs.edit().putString("last_lang", availKeys.get(pos)).apply();
                loadLanguage(availKeys.get(pos));
            }
        });
        engineSpinner.setOnItemSelectedListener(new Sel() {
            @Override void changed(int pos) {
                if (pos == curEngineIdx || pos < 0 || pos >= curEngines.size() || curKey == null) return;
                curEngineIdx = pos;
                EngineItem e = curEngines.get(pos);
                prefs.edit().putString(curKey + "_engine", e.pkg).apply();
                loadVoices(curKey, e);
                saved();
            }
        });
        voiceSpinner.setOnItemSelectedListener(new Sel() {
            @Override void changed(int pos) {
                if (pos == curVoiceIdx || pos < 0 || pos >= curVoices.size() || curKey == null) return;
                curVoiceIdx = pos;
                saveVoice(curKey, curVoices.get(pos));
                saved();
            }
        });
        speedSpinner.setOnItemSelectedListener(new Sel() {
            @Override void changed(int pos) {
                if (pos == curSpeedIdx || pos < 0 || pos >= SPEEDS.length || curKey == null) return;
                curSpeedIdx = pos;
                prefs.edit().putFloat(curKey + "_speed", SPEEDS[pos]).apply();
                saved();
            }
        });
        pitchSpinner.setOnItemSelectedListener(new Sel() {
            @Override void changed(int pos) {
                if (pos == curPitchIdx || pos < 0 || pos >= PITCHES.length || curKey == null) return;
                curPitchIdx = pos;
                prefs.edit().putFloat(curKey + "_pitch", PITCHES[pos]).apply();
                saved();
            }
        });
        volumeSpinner.setOnItemSelectedListener(new Sel() {
            @Override void changed(int pos) {
                if (pos == curVolumeIdx || pos < 0 || pos >= VOLUMES.length || curKey == null) return;
                curVolumeIdx = pos;
                prefs.edit().putFloat(curKey + "_volume", VOLUMES[pos]).apply();
                saved();
            }
        });
        boostBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                if (curKey == null) return;
                if (prefs.getBoolean(curKey + "_boost", false) == checked) return;
                prefs.edit().putBoolean(curKey + "_boost", checked).apply();
                saved();
            }
        });
    }

    private abstract static class Sel implements AdapterView.OnItemSelectedListener {
        abstract void changed(int pos);
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { changed(position); }
        @Override public void onNothingSelected(AdapterView<?> parent) { }
    }

    private Spinner addSpinner(LinearLayout root, String label) {
        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(16);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(0, pad, 0, 0);
        Spinner sp = new Spinner(this);
        sp.setId(View.generateViewId());
        tv.setLabelFor(sp.getId());
        root.addView(tv);
        root.addView(sp);
        return sp;
    }

    private void setItems(Spinner sp, List<String> items) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(a);
    }

    private void saveVoice(String key, VoiceItem v) {
        prefs.edit()
                .putString(key + "_voice", v.name)
                .putString(key + "_locale", v.tag == null ? "" : v.tag)
                .apply();
    }

    private void saved() {
        statusText.setText("सेटिंग सेव हो गई");
    }

    // ------------------------------------------------------------ scanning installed engines
    private void startScan() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> services = pm.queryIntentServices(new Intent("android.intent.action.TTS_SERVICE"), 0);
        List<String> pkgs = new ArrayList<>();
        Map<String, String> labels = new HashMap<>();
        for (ResolveInfo ri : services) {
            if (ri.serviceInfo == null) continue;
            String pkg = ri.serviceInfo.packageName;
            if (pkg.equals(getPackageName()) || pkgs.contains(pkg)) continue;
            pkgs.add(pkg);
            CharSequence l = null;
            try { l = ri.loadLabel(pm); } catch (Exception ignored) { }
            labels.put(pkg, l != null ? l.toString() : pkg);
        }
        if (pkgs.isEmpty()) {
            finishScan();
            return;
        }
        pendingProbes = pkgs.size();
        for (final String pkg : pkgs) {
            final EngineItem item = new EngineItem();
            item.pkg = pkg;
            item.label = labels.get(pkg);
            final TextToSpeech[] holder = new TextToSpeech[1];
            try {
                holder[0] = new TextToSpeech(getApplicationContext(),
                        status -> onProbeReady(item, status, holder[0]), pkg);
                probes.add(holder[0]);
            } catch (Exception e) {
                pendingProbes--;
            }
        }
        if (pendingProbes <= 0) finishScan();
        handler.postDelayed(this::finishScan, 7000);
    }

    private void onProbeReady(EngineItem item, int status, TextToSpeech probe) {
        if (scanFinished) {
            if (probe != null) {
                try { probe.shutdown(); } catch (Exception ignored) { }
            }
            return;
        }
        if (status == TextToSpeech.SUCCESS && probe != null) {
            collect(item, probe);
        }
        if (probe != null) {
            try { probe.shutdown(); } catch (Exception ignored) { }
        }
        if (!item.byLang.isEmpty()) engines.add(item);
        pendingProbes--;
        if (pendingProbes <= 0) finishScan();
    }

    private static void addVoice(EngineItem item, String key, VoiceItem vi) {
        List<VoiceItem> list = item.byLang.get(key);
        if (list == null) {
            list = new ArrayList<>();
            item.byLang.put(key, list);
        }
        list.add(vi);
    }

    private void collect(EngineItem item, TextToSpeech t) {
        Set<Voice> voices = null;
        try { voices = t.getVoices(); } catch (Exception ignored) { }
        if (voices != null) {
            for (Voice v : voices) {
                try {
                    if (v.getFeatures() != null
                            && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                    String key = Langs.key(v.getLocale().getLanguage());
                    if (key == null || key.isEmpty()) continue;
                    VoiceItem vi = new VoiceItem();
                    vi.name = v.getName();
                    vi.tag = v.getLocale().toLanguageTag();
                    vi.label = v.getLocale().getDisplayName() + " - " + v.getName()
                            + (v.isNetworkConnectionRequired() ? " (नेटवर्क चाहिए)" : "");
                    addVoice(item, key, vi);
                } catch (Exception ignored) { }
            }
        }
        // Languages the engine lists without separate voices.
        Set<Locale> langs = null;
        try { langs = t.getAvailableLanguages(); } catch (Exception ignored) { }
        if (langs != null) {
            for (Locale l : langs) {
                try {
                    String key = Langs.key(l.getLanguage());
                    if (key == null || key.isEmpty() || item.byLang.containsKey(key)) continue;
                    VoiceItem vi = new VoiceItem();
                    vi.name = "";
                    vi.tag = l.toLanguageTag();
                    vi.label = "डिफ़ॉल्ट वॉइस";
                    addVoice(item, key, vi);
                } catch (Exception ignored) { }
            }
        }
        for (List<VoiceItem> list : item.byLang.values()) {
            Collections.sort(list, new Comparator<VoiceItem>() {
                @Override public int compare(VoiceItem a, VoiceItem b) { return a.label.compareToIgnoreCase(b.label); }
            });
        }
    }

    private static int langRank(String key) {
        if ("hi".equals(key)) return 0;
        if ("en".equals(key)) return 1;
        return 2;
    }

    private void finishScan() {
        if (scanFinished) return;
        scanFinished = true;
        for (TextToSpeech p : probes) {
            try { p.shutdown(); } catch (Exception ignored) { }
        }
        probes.clear();

        Collections.sort(engines, new Comparator<EngineItem>() {
            @Override public int compare(EngineItem a, EngineItem b) { return a.label.compareToIgnoreCase(b.label); }
        });

        availKeys.clear();
        Set<String> found = new HashSet<>();
        for (EngineItem e : engines) found.addAll(e.byLang.keySet());
        availKeys.addAll(found);
        Collections.sort(availKeys, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                int ra = langRank(a), rb = langRank(b);
                if (ra != rb) return ra - rb;
                return Langs.displayName(a).compareToIgnoreCase(Langs.displayName(b));
            }
        });
        List<String> names = new ArrayList<>();
        for (String k : availKeys) names.add(Langs.displayName(k));
        if (availKeys.isEmpty()) {
            statusText.setText("कोई TTS इंजन या वॉइस नहीं मिली।");
            return;
        }
        setItems(languageSpinner, names);
        String last = prefs.getString("last_lang", null);
        int idx = 0;
        for (int i = 0; i < availKeys.size(); i++) if (availKeys.get(i).equals(last)) idx = i;
        curLangIdx = idx;
        languageSpinner.setSelection(idx);
        statusText.setText("तैयार। डिवाइस पर मिली सभी भाषाएँ सूची में हैं। सेटिंग अपने आप सेव होती है।");
        loadLanguage(availKeys.get(idx));
    }

    // ------------------------------------------------------------ loading saved settings into the spinners
    private void loadLanguage(String key) {
        curKey = key;
        curEngines = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (EngineItem e : engines) {
            List<VoiceItem> l = e.byLang.get(key);
            if (l != null && !l.isEmpty()) {
                curEngines.add(e);
                names.add(e.label);
            }
        }
        setItems(engineSpinner, names);
        String savedEngine = prefs.getString(key + "_engine", null);
        int idx = -1;
        for (int i = 0; i < curEngines.size(); i++) if (curEngines.get(i).pkg.equals(savedEngine)) idx = i;
        if (idx < 0) for (int i = 0; i < curEngines.size(); i++) if (curEngines.get(i).pkg.equals(FALLBACK_ENGINE)) idx = i;
        if (idx < 0) idx = 0;
        curEngineIdx = idx;
        engineSpinner.setSelection(idx);
        prefs.edit().putString(key + "_engine", curEngines.get(idx).pkg).apply();
        loadVoices(key, curEngines.get(idx));

        List<String> speedNames = new ArrayList<>();
        for (float f : SPEEDS) speedNames.add(fmt(f) + "x");
        setItems(speedSpinner, speedNames);
        curSpeedIdx = nearest(SPEEDS, prefs.getFloat(key + "_speed", 1f));
        speedSpinner.setSelection(curSpeedIdx);

        List<String> pitchNames = new ArrayList<>();
        for (float f : PITCHES) pitchNames.add(fmt(f));
        setItems(pitchSpinner, pitchNames);
        curPitchIdx = nearest(PITCHES, prefs.getFloat(key + "_pitch", 1f));
        pitchSpinner.setSelection(curPitchIdx);

        List<String> volNames = new ArrayList<>();
        for (float f : VOLUMES) volNames.add(Math.round(f * 100) + "%");
        setItems(volumeSpinner, volNames);
        curVolumeIdx = nearest(VOLUMES, prefs.getFloat(key + "_volume", 1f));
        volumeSpinner.setSelection(curVolumeIdx);

        boostBox.setChecked(prefs.getBoolean(key + "_boost", false));
    }

    private void loadVoices(String key, EngineItem e) {
        curVoices = e.byLang.get(key);
        if (curVoices == null) curVoices = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (VoiceItem v : curVoices) names.add(v.label);
        setItems(voiceSpinner, names);
        String savedVoice = prefs.getString(key + "_voice", null);
        int idx = 0;
        for (int i = 0; i < curVoices.size(); i++) if (curVoices.get(i).name.equals(savedVoice)) idx = i;
        curVoiceIdx = idx;
        voiceSpinner.setSelection(idx);
        if (!curVoices.isEmpty()) {
            saveVoice(key, curVoices.get(idx));
        }
    }

    private static int nearest(float[] arr, float value) {
        int best = 0;
        float bestDiff = Float.MAX_VALUE;
        for (int i = 0; i < arr.length; i++) {
            float d = Math.abs(arr[i] - value);
            if (d < bestDiff) { bestDiff = d; best = i; }
        }
        return best;
    }

    private static String fmt(float f) {
        String s = String.format(Locale.US, "%.2f", f);
        if (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        if (s.endsWith("0")) s = s.substring(0, s.length() - 2);
        return s;
    }

    // ------------------------------------------------------------ test speaking through our own engine
    private void speakTest() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) text = "नमस्ते, यह एक टेस्ट है. Hello, this is a test.";
        if (testTts == null) {
            pendingTestText = text;
            statusText.setText("टेस्ट इंजन तैयार हो रहा है...");
            testTts = new TextToSpeech(getApplicationContext(), status -> {
                testReady = (status == TextToSpeech.SUCCESS);
                if (testReady && pendingTestText != null) {
                    testTts.speak(pendingTestText, TextToSpeech.QUEUE_FLUSH, null, "test");
                    statusText.setText("बोल रहा है");
                } else if (!testReady) {
                    statusText.setText("टेस्ट इंजन शुरू नहीं हो सका");
                }
            }, getPackageName());
        } else if (testReady) {
            testTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test");
            statusText.setText("बोल रहा है");
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        for (TextToSpeech p : probes) {
            try { p.shutdown(); } catch (Exception ignored) { }
        }
        if (testTts != null) {
            try { testTts.shutdown(); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
}
