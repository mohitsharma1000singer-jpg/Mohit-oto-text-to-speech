package com.mohit.dualtts;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String PREFS = "dual_tts_prefs";
    private static final String KEY_HINDI_ENGINE = "hindi_engine";
    private static final String KEY_HINDI_VOICE = "hindi_voice";
    private static final String KEY_ENGLISH_ENGINE = "english_engine";
    private static final String KEY_ENGLISH_VOICE = "english_voice";

    private SharedPreferences prefs;

    private Spinner hindiEngineSpinner, hindiVoiceSpinner, englishEngineSpinner, englishVoiceSpinner;
    private TextView statusText;
    private EditText inputText;
    private Button speakButton;

    private List<TextToSpeech.EngineInfo> allEngines = new ArrayList<>();
    private List<Voice> hindiVoices = new ArrayList<>();
    private List<Voice> englishVoices = new ArrayList<>();

    private TextToSpeech hindiTts, englishTts;
    private boolean hindiReady = false;
    private boolean englishReady = false;

    // guards so programmatic spinner population doesn't trigger save/reload loops
    private boolean populatingHindiEngine = false;
    private boolean populatingHindiVoice = false;
    private boolean populatingEnglishEngine = false;
    private boolean populatingEnglishVoice = false;

    private String[] tokens;
    private int currentIndex = 0;

    private void startRecordingNow(TextView recordingStatusText) {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 501);
        }
        Intent svc = new Intent(this, LogCaptureService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        recordingStatusText.setText("Recording: checking...");

        // confirm after a short delay by actually checking whether our own
        // service is running, rather than just assuming the start succeeded
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            boolean running = isLogServiceRunning();
            if (running) {
                recordingStatusText.setText("Recording: ON (confirmed running)");
                recordingStatusText.announceForAccessibility("Recording is on");
            } else {
                recordingStatusText.setText("Recording: NOT running -- check notification permission");
                recordingStatusText.announceForAccessibility("Recording did not start");
            }
        }, 1500);
    }

    private boolean isLogServiceRunning() {
        android.app.ActivityManager manager =
                (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (manager == null) return false;
        for (android.app.ActivityManager.RunningServiceInfo service :
                manager.getRunningServices(Integer.MAX_VALUE)) {
            if (LogCaptureService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLogger.install(getApplicationContext());
        CrashLogger.log(this, "ACTIVITY", "onCreate started, action=" + getIntent().getAction());

        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        hindiEngineSpinner = findViewById(R.id.hindiEngineSpinner);
        hindiVoiceSpinner = findViewById(R.id.hindiVoiceSpinner);
        englishEngineSpinner = findViewById(R.id.englishEngineSpinner);
        englishVoiceSpinner = findViewById(R.id.englishVoiceSpinner);
        statusText = findViewById(R.id.statusText);
        inputText = findViewById(R.id.inputText);
        speakButton = findViewById(R.id.speakButton);

        TextView recordingStatusText = findViewById(R.id.recordingStatusText);

        // Recording starts automatically the moment the app opens, so timing
        // never depends on how fast the user can tap a button.
        startRecordingNow(recordingStatusText);

        Button stopRecordingButton = findViewById(R.id.stopRecordingButton);
        stopRecordingButton.setOnClickListener(v -> {
            stopService(new Intent(this, LogCaptureService.class));
            StringBuilder combined = new StringBuilder();
            combined.append("=== APP'S OWN TIMING LOG ===\n");
            combined.append(CrashLogger.readLog(this));
            combined.append("\n\n=== FULL SYSTEM LOGCAT (main+system+crash+events) ===\n");
            try {
                java.io.File logFile = new java.io.File(getFilesDir(), LogCaptureService.LOG_FILE_NAME);
                if (!logFile.exists()) {
                    combined.append("No recording found yet.");
                } else {
                    java.io.FileInputStream fis = new java.io.FileInputStream(logFile);
                    byte[] data = new byte[(int) logFile.length()];
                    fis.read(data);
                    fis.close();
                    combined.append(new String(data, "UTF-8"));
                }
            } catch (Exception e) {
                combined.append("Could not read recording: ").append(e.getMessage());
            }
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Pocket Dual TTS - Log");
            shareIntent.putExtra(Intent.EXTRA_TEXT, combined.toString());
            startActivity(Intent.createChooser(shareIntent, "Share log"));
        });

        speakButton.setOnClickListener(v -> {
            String text = inputText.getText().toString().trim();
            if (!text.isEmpty()) {
                tokens = text.split("\\s+");
                currentIndex = 0;
                speakToken(currentIndex);
            }
        });

        scanEnginesAndPopulate();
    }

    // ---------- Step 1: scan every installed TTS engine on the device ----------
    // We ask PackageManager directly (rather than only TextToSpeech.getEngines())
    // and explicitly include disabled/not-yet-enabled components, so an
    // OEM-bundled TTS engine that hasn't been "activated" yet still shows up.
    private void scanEnginesAndPopulate() {
        statusText.setText("इंजन खोजे जा रहे हैं...");

        PackageManager pm = getPackageManager();
        Intent ttsIntent = new Intent("android.intent.action.TTS_SERVICE");
        List<ResolveInfo> resolveInfos;
        try {
            resolveInfos = pm.queryIntentServices(ttsIntent, PackageManager.MATCH_ALL);
        } catch (Exception e) {
            resolveInfos = pm.queryIntentServices(ttsIntent, PackageManager.GET_META_DATA);
        }

        allEngines = new ArrayList<>();
        if (resolveInfos != null) {
            for (ResolveInfo ri : resolveInfos) {
                if (ri.serviceInfo == null) continue;
                String pkg = ri.serviceInfo.packageName;
                // never let our own engine be picked as its own backend --
                // that would make the app call itself and hang forever.
                if (pkg.equals(getPackageName())) continue;
                TextToSpeech.EngineInfo info = new TextToSpeech.EngineInfo();
                info.name = pkg;
                info.label = ri.loadLabel(pm).toString();
                allEngines.add(info);
            }
        }

        // announce exactly what was found, so this is verifiable by ear via TalkBack
        StringBuilder found = new StringBuilder();
        for (TextToSpeech.EngineInfo e : allEngines) {
            if (found.length() > 0) found.append(", ");
            found.append(e.label);
        }
        statusText.setText(allEngines.size() + " इंजन मिले: " + found);
        statusText.announceForAccessibility(allEngines.size() + " टीटीएस इंजन मिले: " + found);

        if (allEngines == null || allEngines.isEmpty()) {
            statusText.setText("कोई TTS इंजन नहीं मिला। Settings में से एक TTS इंजन इंस्टॉल करें।");
            statusText.announceForAccessibility(statusText.getText().toString());
            return;
        }

        String[] engineLabels = new String[allEngines.size()];
        for (int i = 0; i < allEngines.size(); i++) {
            engineLabels[i] = allEngines.get(i).label;
        }

        ArrayAdapter<String> hindiEngineAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, engineLabels);
        hindiEngineAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ArrayAdapter<String> englishEngineAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, engineLabels);
        englishEngineAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        populatingHindiEngine = true;
        hindiEngineSpinner.setAdapter(hindiEngineAdapter);
        populatingEnglishEngine = true;
        englishEngineSpinner.setAdapter(englishEngineAdapter);

        // restore previously saved engine choice, else default to first in list
        String savedHindiEngine = prefs.getString(KEY_HINDI_ENGINE, allEngines.get(0).name);
        String savedEnglishEngine = prefs.getString(KEY_ENGLISH_ENGINE, allEngines.get(0).name);
        hindiEngineSpinner.setSelection(indexOfEnginePackage(savedHindiEngine));
        englishEngineSpinner.setSelection(indexOfEnginePackage(savedEnglishEngine));
        populatingHindiEngine = false;
        populatingEnglishEngine = false;

        // now actually initialize both engines with the restored (or default) choice
        setupHindiEngine(savedHindiEngine);
        setupEnglishEngine(savedEnglishEngine);

        hindiEngineSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (populatingHindiEngine) return;
                String enginePackage = allEngines.get(position).name;
                prefs.edit().putString(KEY_HINDI_ENGINE, enginePackage).apply();
                setupHindiEngine(enginePackage);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        englishEngineSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (populatingEnglishEngine) return;
                String enginePackage = allEngines.get(position).name;
                prefs.edit().putString(KEY_ENGLISH_ENGINE, enginePackage).apply();
                setupEnglishEngine(enginePackage);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        hindiVoiceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (populatingHindiVoice || position >= hindiVoices.size()) return;
                Voice v = hindiVoices.get(position);
                if (hindiTts != null) hindiTts.setVoice(v);
                prefs.edit().putString(KEY_HINDI_VOICE, v.getName()).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        englishVoiceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (populatingEnglishVoice || position >= englishVoices.size()) return;
                Voice v = englishVoices.get(position);
                if (englishTts != null) englishTts.setVoice(v);
                prefs.edit().putString(KEY_ENGLISH_VOICE, v.getName()).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private int indexOfEnginePackage(String pkg) {
        for (int i = 0; i < allEngines.size(); i++) {
            if (allEngines.get(i).name.equals(pkg)) return i;
        }
        return 0;
    }

    // ---------- Step 2: initialize the chosen engine for a language, then populate its voice dropdown ----------
    private void setupHindiEngine(String enginePackage) {
        if (hindiTts != null) hindiTts.shutdown();
        hindiReady = false;
        speakButton.setEnabled(false);
        hindiTts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                statusText.setText("हिंदी इंजन शुरू नहीं हो पाया।");
                return;
            }
            // The init callback can fire slightly before the engine connection
            // is truly ready for setLanguage()/getVoices() -- a short settle
            // delay avoids the "connection not fully set up" warning/failure.
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                Locale locale = new Locale("hi", "IN");
                hindiTts.setLanguage(locale);
                populateVoiceSpinner(true, hindiTts, locale);
            }, 300);
        }, enginePackage);
    }

    private void setupEnglishEngine(String enginePackage) {
        if (englishTts != null) englishTts.shutdown();
        englishReady = false;
        speakButton.setEnabled(false);
        englishTts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                statusText.setText("English इंजन शुरू नहीं हो पाया।");
                return;
            }
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                englishTts.setLanguage(Locale.US);
                populateVoiceSpinner(false, englishTts, Locale.US);
            }, 300);
        }, enginePackage);
    }

    // ---------- Step 3: list this engine's voices for the language, restore saved choice ----------
    private void populateVoiceSpinner(boolean forHindi, TextToSpeech tts, Locale locale) {
        List<Voice> matching = new ArrayList<>();
        if (tts.getVoices() != null) {
            for (Voice v : tts.getVoices()) {
                if (v.getLocale() != null && v.getLocale().getLanguage().equals(locale.getLanguage())) {
                    matching.add(v);
                }
            }
        }

        String[] names = new String[Math.max(matching.size(), 1)];
        if (matching.isEmpty()) {
            names[0] = "डिफ़ॉल्ट वॉइस";
        } else {
            for (int i = 0; i < matching.size(); i++) names[i] = matching.get(i).getName();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        String savedVoiceName = prefs.getString(forHindi ? KEY_HINDI_VOICE : KEY_ENGLISH_VOICE, null);
        int selectIndex = 0;
        for (int i = 0; i < matching.size(); i++) {
            if (matching.get(i).getName().equals(savedVoiceName)) { selectIndex = i; break; }
        }

        if (forHindi) {
            hindiVoices = matching;
            populatingHindiVoice = true;
            hindiVoiceSpinner.setAdapter(adapter);
            hindiVoiceSpinner.setSelection(selectIndex);
            populatingHindiVoice = false;
            if (!matching.isEmpty()) {
                tts.setVoice(matching.get(selectIndex));
                prefs.edit().putString(KEY_HINDI_VOICE, matching.get(selectIndex).getName()).apply();
            }
            hindiReady = true;
        } else {
            englishVoices = matching;
            populatingEnglishVoice = true;
            englishVoiceSpinner.setAdapter(adapter);
            englishVoiceSpinner.setSelection(selectIndex);
            populatingEnglishVoice = false;
            if (!matching.isEmpty()) {
                tts.setVoice(matching.get(selectIndex));
                prefs.edit().putString(KEY_ENGLISH_VOICE, matching.get(selectIndex).getName()).apply();
            }
            englishReady = true;
        }

        attachListeners();
        checkReady();
    }

    private void checkReady() {
        if (hindiReady && englishReady) {
            statusText.setText("तैयार है। टेक्स्ट लिखें और बोलें दबाएं। ऊपर से इंजन/वॉइस कभी भी बदल सकते हैं।");
            statusText.announceForAccessibility("तैयार है। टेक्स्ट लिखें और बोलें दबाएं।");
            speakButton.setEnabled(true);
        }
    }

    // ---------- sequential speaking, order preserved, no engine-switch delay since both are pre-warmed ----------
    private void attachListeners() {
        UtteranceProgressListener listener = new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) { }

            @Override public void onDone(String utteranceId) {
                currentIndex++;
                runOnUiThread(() -> speakToken(currentIndex));
            }

            @Override public void onError(String utteranceId) {
                currentIndex++;
                runOnUiThread(() -> speakToken(currentIndex));
            }
        };
        if (hindiTts != null) hindiTts.setOnUtteranceProgressListener(listener);
        if (englishTts != null) englishTts.setOnUtteranceProgressListener(listener);
    }

    private void speakToken(int index) {
        if (tokens == null || index >= tokens.length) return;
        String word = tokens[index];
        String utteranceId = "word_" + index;

        if (isHindi(word)) {
            if (hindiTts != null) hindiTts.speak(word + " ", TextToSpeech.QUEUE_FLUSH, null, utteranceId);
        } else {
            if (englishTts != null) englishTts.speak(word + " ", TextToSpeech.QUEUE_FLUSH, null, utteranceId);
        }
    }

    private boolean isHindi(String text) {
        for (char c : text.toCharArray()) {
            if (Character.UnicodeBlock.of(c) == Character.UnicodeBlock.DEVANAGARI) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        if (hindiTts != null) hindiTts.shutdown();
        if (englishTts != null) englishTts.shutdown();
        super.onDestroy();
    }
}
