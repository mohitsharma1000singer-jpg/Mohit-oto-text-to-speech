package com.mohit.dualtts;

import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

// Small helpers shared by the settings screen and the engine service.
// A "language key" is the 2-letter code (hi, en, ta ...), or the 3-letter
// code when the language has no 2-letter one.
final class Langs {
    private Langs() { }

    static final String PREFS = "dual_tts_prefs";

    private static Map<String, String> iso3to2;

    static synchronized String key(String code) {
        if (code == null) return null;
        code = code.toLowerCase(Locale.ROOT);
        if (code.length() <= 2) return code;
        if (iso3to2 == null) {
            Map<String, String> m = new HashMap<>();
            for (String two : Locale.getISOLanguages()) {
                try {
                    m.put(new Locale(two).getISO3Language().toLowerCase(Locale.ROOT), two);
                } catch (Exception ignored) { }
            }
            iso3to2 = m;
        }
        String two = iso3to2.get(code);
        return two != null ? two : code;
    }

    static String iso3(String key) {
        try {
            return new Locale(key).getISO3Language();
        } catch (Exception e) {
            return key;
        }
    }

    static Locale defaultLocale(String key) {
        if ("hi".equals(key)) return new Locale("hi", "IN");
        if ("en".equals(key)) return Locale.US;
        return new Locale(key);
    }

    static String displayName(String key) {
        Locale l = new Locale(key);
        String a = l.getDisplayLanguage(Locale.getDefault());
        String b = l.getDisplayLanguage(l);
        if (a == null || a.isEmpty()) a = key;
        if (b != null && !b.isEmpty() && !b.equalsIgnoreCase(a)) return a + " (" + b + ")";
        return a;
    }

    // Languages the user has configured, plus Hindi and English which always work.
    static Set<String> configured(SharedPreferences p) {
        Set<String> out = new HashSet<>();
        out.add("hi");
        out.add("en");
        for (String k : p.getAll().keySet()) {
            if (k.endsWith("_engine")) {
                String lang = k.substring(0, k.length() - 7);
                if (lang.length() >= 2 && lang.length() <= 3) out.add(lang);
            }
        }
        return out;
    }

    // Which language a character belongs to, judged by its script.
    // Returns null for digits, spaces, punctuation etc. (they stay with the
    // surrounding text).
    static String scriptLang(int cp) {
        Character.UnicodeScript s;
        try {
            s = Character.UnicodeScript.of(cp);
        } catch (Exception e) {
            return null;
        }
        switch (s) {
            case DEVANAGARI: return "hi";
            case BENGALI: return "bn";
            case GURMUKHI: return "pa";
            case GUJARATI: return "gu";
            case ORIYA: return "or";
            case TAMIL: return "ta";
            case TELUGU: return "te";
            case KANNADA: return "kn";
            case MALAYALAM: return "ml";
            case SINHALA: return "si";
            case ARABIC: return "ar";
            case CYRILLIC: return "ru";
            case GREEK: return "el";
            case HEBREW: return "he";
            case THAI: return "th";
            case HANGUL: return "ko";
            case HIRAGANA: return "ja";
            case KATAKANA: return "ja";
            case HAN: return "zh";
            case LATIN: return "en";
            default: return null;
        }
    }
}
