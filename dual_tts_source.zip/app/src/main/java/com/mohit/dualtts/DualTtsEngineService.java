package com.mohit.dualtts;

import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.speech.tts.SynthesisCallback;
import android.speech.tts.SynthesisRequest;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeechService;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

// This Service is what makes our app show up in
// Settings > Accessibility > Text-to-speech output, selectable by TalkBack
// or any other app as the active system TTS engine.
//
// IMPORTANT LESSON FROM A REAL BUG: every backend TextToSpeech object below
// is created and driven from "backendThread" -- a single dedicated thread
// that we start once and that has its own proper Android message loop
// (Looper). Android's TextToSpeech client relies on a Looper to reliably
// deliver its "I'm connected" and "I'm done speaking" callbacks. Creating
// it from whatever random thread the system happens to call us on (no
// Looper there) is what caused the earlier bug: callbacks sometimes never
// arrived, which meant nothing spoke, and Settings itself hung/crashed
// when it tried to preview our engine and got no response in time.
public class DualTtsEngineService extends TextToSpeechService {

    private static final int TARGET_SAMPLE_RATE = 22050;
    private static final long CONNECT_TIMEOUT_MS = 2500;
    private static final long CHUNK_SYNTH_TIMEOUT_MS = 2500;
    private static final long MAX_TOTAL_SYNTH_MS = 6000;

    private SharedPreferences prefs;
    private HandlerThread backendThread;
    private Handler backendHandler;

    private TextToSpeech hindiBackend, englishBackend;
    private String currentHindiEngine, currentEnglishEngine;
    private volatile boolean stopRequested = false;
    // Whatever synthesis wait is currently blocked (if any) -- onStop() counts
    // this down immediately instead of letting it sit through the full timeout.
    private volatile CountDownLatch currentSynthLatch = null;

    @Override
    public void onCreate() {
        super.onCreate();
        CrashLogger.install(getApplicationContext());
        CrashLogger.log(this, "SERVICE", "onCreate started");
        prefs = getSharedPreferences("dual_tts_prefs", MODE_PRIVATE);

        backendThread = new HandlerThread("DualTtsBackendThread");
        backendThread.start();
        backendHandler = new Handler(backendThread.getLooper());

        // Fire-and-forget prewarm: doesn't block onCreate (safe), but gives
        // the connection a head start so a fresh process isn't fully cold
        // on the very first real request.
        backendHandler.post(() -> {
            CrashLogger.log(this, "PREWARM", "starting");
            connectHindiOnBackendThread();
            connectEnglishOnBackendThread();
            CrashLogger.log(this, "PREWARM", "done");
        });
    }

    @Override
    public void onDestroy() {
        CrashLogger.log(this, "SERVICE", "onDestroy");
        if (hindiBackend != null) hindiBackend.shutdown();
        if (englishBackend != null) englishBackend.shutdown();
        if (backendThread != null) backendThread.quitSafely();
        super.onDestroy();
    }

    // ---------- language capability reporting (lightweight, never touches backends) ----------
    @Override
    protected String[] onGetLanguage() {
        CrashLogger.log(this, "GET-LANG", "called");
        return new String[]{"hin", "IND", ""};
    }

    @Override
    protected int onIsLanguageAvailable(String lang, String country, String variant) {
        CrashLogger.log(this, "LANG-CHECK", lang + "/" + country);
        if ("hin".equals(lang) || "eng".equals(lang)) {
            return TextToSpeech.LANG_COUNTRY_AVAILABLE;
        }
        return TextToSpeech.LANG_NOT_SUPPORTED;
    }

    @Override
    protected int onLoadLanguage(String lang, String country, String variant) {
        CrashLogger.log(this, "LOAD-LANG", "start " + lang + "/" + country);
        int result = onIsLanguageAvailable(lang, country, variant);
        CrashLogger.log(this, "LOAD-LANG", "done " + lang + "/" + country);
        return result;
    }

    @Override
    public List<Voice> onGetVoices() {
        CrashLogger.log(this, "GET-VOICES", "start");
        List<Voice> voices = new ArrayList<>();
        // Never pass null for features: Settings / apps may call
        // voice.getFeatures().contains(...) and a null set would crash THEM.
        voices.add(new Voice("hi-in-dual", new Locale("hi", "IN"), Voice.QUALITY_NORMAL, Voice.LATENCY_NORMAL, false, new HashSet<String>()));
        voices.add(new Voice("en-us-dual", Locale.US, Voice.QUALITY_NORMAL, Voice.LATENCY_NORMAL, false, new HashSet<String>()));
        voices.add(new Voice("en-gb-dual", Locale.UK, Voice.QUALITY_NORMAL, Voice.LATENCY_NORMAL, false, new HashSet<String>()));
        voices.add(new Voice("en-in-dual", new Locale("en", "IN"), Voice.QUALITY_NORMAL, Voice.LATENCY_NORMAL, false, new HashSet<String>()));
        CrashLogger.log(this, "GET-VOICES", "done, count=" + voices.size());
        return voices;
    }

    @Override
    public String onGetDefaultVoiceNameFor(String lang, String country, String variant) {
        CrashLogger.log(this, "DEFAULT-VOICE", "called " + lang + "/" + country);
        if ("hin".equals(lang)) return "hi-in-dual";
        if ("GBR".equals(country)) return "en-gb-dual";
        if ("IND".equals(country)) return "en-in-dual";
        return "en-us-dual";
    }

    private static boolean isOurVoice(String voiceName) {
        return "hi-in-dual".equals(voiceName) || "en-us-dual".equals(voiceName)
                || "en-gb-dual".equals(voiceName) || "en-in-dual".equals(voiceName);
    }

    @Override
    public int onIsValidVoiceName(String voiceName) {
        CrashLogger.log(this, "VALID-VOICE", "start " + voiceName);
        int result = isOurVoice(voiceName) ? TextToSpeech.SUCCESS : TextToSpeech.ERROR;
        CrashLogger.log(this, "VALID-VOICE", "done " + voiceName);
        return result;
    }

    @Override
    public int onLoadVoice(String voiceName) {
        CrashLogger.log(this, "LOAD-VOICE", "start " + voiceName);
        int result = onIsValidVoiceName(voiceName);
        CrashLogger.log(this, "LOAD-VOICE", "done " + voiceName);
        return result;
    }

    @Override
    protected void onStop() {
        CrashLogger.log(this, "STOP", "called");
        stopRequested = true;
        if (hindiBackend != null) hindiBackend.stop();
        if (englishBackend != null) englishBackend.stop();
        // Don't make the caller (often Settings itself) wait through our full
        // timeout just because it asked us to stop -- wake up immediately.
        CountDownLatch waiting = currentSynthLatch;
        if (waiting != null) waiting.countDown();
    }

    // if the user never opened the app to pick an engine (e.g. right after a
    // fresh install, before configuring), fall back to Google's engine rather
    // than staying silent forever.
    private static final String FALLBACK_ENGINE = "com.google.android.tts";

    private void connectHindiOnBackendThread() {
        String wanted = prefs.getString("hindi_engine", FALLBACK_ENGINE);
        // Never use ourselves as our own backend (infinite loop / hang).
        if (wanted == null || wanted.equals(getPackageName())) wanted = FALLBACK_ENGINE;
        if (hindiBackend != null && wanted.equals(currentHindiEngine)) return;
        if (hindiBackend != null) hindiBackend.shutdown();
        currentHindiEngine = wanted;

        hindiBackend = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS && hindiBackend != null) {
                hindiBackend.setLanguage(new Locale("hi", "IN"));
                String savedVoice = prefs.getString("hindi_voice", null);
                if (savedVoice != null && hindiBackend.getVoices() != null) {
                    for (Voice v : hindiBackend.getVoices()) {
                        if (v.getName().equals(savedVoice)) { hindiBackend.setVoice(v); break; }
                    }
                }
            }
        }, wanted);
    }

    private void connectEnglishOnBackendThread() {
        String wanted = prefs.getString("english_engine", FALLBACK_ENGINE);
        if (wanted == null || wanted.equals(getPackageName())) wanted = FALLBACK_ENGINE;
        if (englishBackend != null && wanted.equals(currentEnglishEngine)) return;
        if (englishBackend != null) englishBackend.shutdown();
        currentEnglishEngine = wanted;

        englishBackend = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS && englishBackend != null) {
                englishBackend.setLanguage(Locale.US);
                String savedVoice = prefs.getString("english_voice", null);
                if (savedVoice != null && englishBackend.getVoices() != null) {
                    for (Voice v : englishBackend.getVoices()) {
                        if (v.getName().equals(savedVoice)) { englishBackend.setVoice(v); break; }
                    }
                }
            }
        }, wanted);
    }

    // ---------- called from the synthesis thread; posts to backendThread and blocks THIS thread only ----------
    private TextToSpeech waitForHindiBackend() {
        CountDownLatch latch = new CountDownLatch(1);
        backendHandler.post(() -> {
            connectHindiOnBackendThread();
            latch.countDown();
        });
        try { latch.await(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
        return hindiBackend;
    }

    private TextToSpeech waitForEnglishBackend() {
        CountDownLatch latch = new CountDownLatch(1);
        backendHandler.post(() -> {
            connectEnglishOnBackendThread();
            latch.countDown();
        });
        try { latch.await(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
        return englishBackend;
    }

    // ---------- the main entry point Android calls to speak text ----------
    @Override
    protected void onSynthesizeText(SynthesisRequest request, SynthesisCallback callback) {
        stopRequested = false;
        long startTime = SystemClock.elapsedRealtime();
        String text = request.getCharSequenceText() != null
                ? request.getCharSequenceText().toString()
                : request.getText();
        if (text == null) text = "";
        CrashLogger.log(this, "SYNTH", "request received, " + text.length() + " chars");

        boolean started = false;
        try {
            for (String[] run : splitByScript(text)) {
                if (stopRequested) break;
                if (SystemClock.elapsedRealtime() - startTime > MAX_TOTAL_SYNTH_MS) {
                    CrashLogger.log(this, "SYNTH", "aborted: exceeded " + MAX_TOTAL_SYNTH_MS + "ms budget");
                    break;
                }

                String chunkText = run[0];
                boolean isHindiChunk = "hi".equals(run[1]);
                if (chunkText.trim().isEmpty()) continue;

                long t1 = SystemClock.elapsedRealtime();
                TextToSpeech backend = isHindiChunk ? waitForHindiBackend() : waitForEnglishBackend();
                long t2 = SystemClock.elapsedRealtime();
                CrashLogger.log(this, "SYNTH", (isHindiChunk ? "hindi" : "english")
                        + " backend wait: " + (t2 - t1) + "ms, got=" + (backend != null));
                if (backend == null) continue;

                PcmAudio pcm = synthesizeChunkBlocking(backend, chunkText, CHUNK_SYNTH_TIMEOUT_MS);
                long t3 = SystemClock.elapsedRealtime();
                CrashLogger.log(this, "SYNTH", "chunk render: " + (t3 - t2) + "ms, got audio="
                        + (pcm != null && pcm.samples != null));
                if (pcm == null || pcm.samples == null || pcm.samples.length == 0) continue;

                short[] resampled = resampleToTarget(pcm.samples, pcm.sampleRate, pcm.channels);

                if (!started) {
                    callback.start(TARGET_SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1);
                    started = true;
                }
                writeShortsToCallback(callback, resampled);
            }
        } catch (Exception e) {
            CrashLogger.log(this, "SYNTH-ERROR", String.valueOf(e));
            if (!started) callback.start(TARGET_SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1);
            callback.error();
            return;
        }

        if (!started) callback.start(TARGET_SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1);
        callback.done();
        CrashLogger.log(this, "SYNTH", "total: " + (SystemClock.elapsedRealtime() - startTime) + "ms");
    }

    private void writeShortsToCallback(SynthesisCallback callback, short[] samples) {
        int maxBytes = callback.getMaxBufferSize();
        byte[] buffer = new byte[samples.length * 2];
        for (int i = 0; i < samples.length; i++) {
            buffer[i * 2] = (byte) (samples[i] & 0xFF);
            buffer[i * 2 + 1] = (byte) ((samples[i] >> 8) & 0xFF);
        }
        int offset = 0;
        while (offset < buffer.length && !stopRequested) {
            int len = Math.min(maxBytes, buffer.length - offset);
            callback.audioAvailable(buffer, offset, len);
            offset += len;
        }
    }

    // ---------- split text into contiguous Hindi (Devanagari) vs non-Hindi runs ----------
    private List<String[]> splitByScript(String text) {
        List<String[]> runs = new ArrayList<>();
        if (text.isEmpty()) return runs;
        StringBuilder buf = new StringBuilder();
        Boolean currentIsHindi = null;
        for (char c : text.toCharArray()) {
            boolean charIsHindi = Character.UnicodeBlock.of(c) == Character.UnicodeBlock.DEVANAGARI;
            boolean isSpace = Character.isWhitespace(c);
            if (currentIsHindi == null) currentIsHindi = charIsHindi;
            if (!isSpace && charIsHindi != currentIsHindi) {
                runs.add(new String[]{buf.toString(), currentIsHindi ? "hi" : "en"});
                buf = new StringBuilder();
                currentIsHindi = charIsHindi;
            }
            buf.append(c);
        }
        if (buf.length() > 0) {
            runs.add(new String[]{buf.toString(), (currentIsHindi != null && currentIsHindi) ? "hi" : "en"});
        }
        return runs;
    }

    // ---------- render one chunk via the real backend engine into raw PCM ----------
    private static class PcmAudio {
        int sampleRate;
        int channels;
        short[] samples;
    }

    // synthesizeToFile + its completion callback are both driven on backendThread's
    // Looper (since the engine object was constructed there); this method just
    // blocks the synthesis thread until that signal arrives, or times out.
    private PcmAudio synthesizeChunkBlocking(TextToSpeech engine, String text, long timeoutMs) {
        try {
            File outFile = File.createTempFile("dualtts_", ".wav", getCacheDir());
            String utteranceId = "chunk_" + System.nanoTime();
            CountDownLatch latch = new CountDownLatch(1);
            currentSynthLatch = latch;

            backendHandler.post(() -> {
                engine.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { if (id.equals(utteranceId)) latch.countDown(); }
                    @Override public void onError(String id) { if (id.equals(utteranceId)) latch.countDown(); }
                });
                engine.synthesizeToFile(text, null, outFile, utteranceId);
            });

            // Poll in short slices instead of one long wait, so a STOP request
            // (which sets stopRequested, and also directly counts this latch
            // down via currentSynthLatch) can abort us almost immediately
            // rather than only after the full timeout elapses.
            long deadline = SystemClock.elapsedRealtime() + timeoutMs;
            boolean finished = false;
            while (SystemClock.elapsedRealtime() < deadline) {
                if (stopRequested) {
                    CrashLogger.log(this, "SYNTH", "chunk aborted early by STOP");
                    break;
                }
                finished = latch.await(100, TimeUnit.MILLISECONDS);
                if (finished) break;
            }

            if (!finished) {
                outFile.delete();
                return null;
            }

            PcmAudio result = readWav(outFile);
            outFile.delete();
            return result;
        } catch (Exception e) {
            return null;
        } finally {
            currentSynthLatch = null;
        }
    }

    private PcmAudio readWav(File file) throws Exception {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] header = new byte[44];
            raf.readFully(header);
            int channels = (header[22] & 0xFF) | ((header[23] & 0xFF) << 8);
            int sampleRate = (header[24] & 0xFF) | ((header[25] & 0xFF) << 8)
                    | ((header[26] & 0xFF) << 16) | ((header[27] & 0xFF) << 24);
            long dataLen = raf.length() - 44;
            byte[] data = new byte[(int) dataLen];
            raf.readFully(data);

            short[] samples = new short[data.length / 2];
            for (int i = 0; i < samples.length; i++) {
                samples[i] = (short) ((data[i * 2] & 0xFF) | (data[i * 2 + 1] << 8));
            }
            PcmAudio pcm = new PcmAudio();
            pcm.sampleRate = sampleRate > 0 ? sampleRate : TARGET_SAMPLE_RATE;
            pcm.channels = channels > 0 ? channels : 1;
            pcm.samples = samples;
            return pcm;
        }
    }

    // ---------- simple linear-interpolation resample + downmix, so mixed-engine chunks share one stream format ----------
    private short[] resampleToTarget(short[] input, int sourceRate, int channels) {
        short[] mono;
        if (channels > 1) {
            mono = new short[input.length / channels];
            for (int i = 0; i < mono.length; i++) {
                int sum = 0;
                for (int c = 0; c < channels; c++) sum += input[i * channels + c];
                mono[i] = (short) (sum / channels);
            }
        } else {
            mono = input;
        }

        if (sourceRate == TARGET_SAMPLE_RATE || mono.length == 0) return mono;

        double ratio = (double) sourceRate / (double) TARGET_SAMPLE_RATE;
        int outLen = (int) (mono.length / ratio);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            double srcPos = i * ratio;
            int idx = (int) srcPos;
            double frac = srcPos - idx;
            short a = mono[Math.min(idx, mono.length - 1)];
            short b = mono[Math.min(idx + 1, mono.length - 1)];
            out[i] = (short) (a + (b - a) * frac);
        }
        return out;
    }
}
