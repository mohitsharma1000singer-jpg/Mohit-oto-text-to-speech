package com.mohit.dualtts;

import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.speech.tts.SynthesisCallback;
import android.speech.tts.SynthesisRequest;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeechService;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

// System TTS engine: shows up in Settings > Text-to-speech output. It owns no
// voice itself. Each stretch of text is handed to whichever engine/voice the
// user chose for that text's language (judged by its script), and the audio
// is stitched back together (with per-language speed, pitch and volume).
public class DualTtsEngineService extends TextToSpeechService {

    private static final int TARGET_SAMPLE_RATE = 22050;
    private static final long CONNECT_TIMEOUT_MS = 2500;
    private static final long CHUNK_SYNTH_TIMEOUT_MS = 2500;
    private static final long MAX_TOTAL_SYNTH_MS = 6000;
    private static final String FALLBACK_ENGINE = "com.google.android.tts";

    // One per language. All access to .tts happens on backendThread.
    private static class Backend {
        final String key;
        TextToSpeech tts;
        String engine;
        String voice;
        float rate = -1f;
        float pitch = -1f;
        volatile boolean ready = false;
        volatile CountDownLatch readyLatch = new CountDownLatch(1);

        Backend(String key) {
            this.key = key;
        }
    }

    private SharedPreferences prefs;
    private HandlerThread backendThread;
    private Handler backendHandler;
    private final Map<String, Backend> backends = new HashMap<>();

    private volatile boolean stopRequested = false;
    private volatile CountDownLatch currentSynthLatch = null;

    @Override
    public void onCreate() {
        // super.onCreate() already calls onLoadLanguage()/onIsLanguageAvailable(),
        // which read the saved settings, so prefs must exist BEFORE it runs.
        prefs = getSharedPreferences(Langs.PREFS, MODE_PRIVATE);
        super.onCreate();
        backendThread = new HandlerThread("DualTtsBackendThread");
        backendThread.start();
        backendHandler = new Handler(backendThread.getLooper());

        // Head start so the first real request isn't fully cold.
        backendHandler.post(() -> {
            try { connectOnBackendThread(getBackend("hi")); } catch (Exception ignored) { }
            try { connectOnBackendThread(getBackend("en")); } catch (Exception ignored) { }
        });
    }

    @Override
    public void onDestroy() {
        for (Backend b : allBackends()) {
            try { if (b.tts != null) b.tts.shutdown(); } catch (Exception ignored) { }
        }
        if (backendThread != null) backendThread.quitSafely();
        super.onDestroy();
    }

    // ---------- language / voice reporting (lightweight, never touches backends) ----------
    @Override
    protected String[] onGetLanguage() {
        return new String[]{"hin", "IND", ""};
    }

    private SharedPreferences p() {
        if (prefs == null) prefs = getSharedPreferences(Langs.PREFS, MODE_PRIVATE);
        return prefs;
    }

    private synchronized Backend getBackend(String key) {
        Backend b = backends.get(key);
        if (b == null) {
            b = new Backend(key);
            backends.put(key, b);
        }
        return b;
    }

    private synchronized List<Backend> allBackends() {
        return new ArrayList<>(backends.values());
    }

    @Override
    protected int onIsLanguageAvailable(String lang, String country, String variant) {
        String k = Langs.key(lang);
        if (k == null || k.isEmpty()) return TextToSpeech.LANG_NOT_SUPPORTED;
        if (!Langs.configured(p()).contains(k)) return TextToSpeech.LANG_NOT_SUPPORTED;
        if ("hi".equals(k) || "en".equals(k)) return TextToSpeech.LANG_COUNTRY_AVAILABLE;
        return TextToSpeech.LANG_AVAILABLE;
    }

    @Override
    protected int onLoadLanguage(String lang, String country, String variant) {
        return onIsLanguageAvailable(lang, country, variant);
    }

    @Override
    public List<Voice> onGetVoices() {
        List<Voice> voices = new ArrayList<>();
        // Never pass null for features: callers may use voice.getFeatures().
        for (String k : Langs.configured(p())) {
            if ("hi".equals(k)) {
                voices.add(makeVoice("hi-in-dual", new Locale("hi", "IN")));
            } else if ("en".equals(k)) {
                voices.add(makeVoice("en-us-dual", Locale.US));
                voices.add(makeVoice("en-gb-dual", Locale.UK));
                voices.add(makeVoice("en-in-dual", new Locale("en", "IN")));
            } else {
                voices.add(makeVoice(k + "-dual", new Locale(k)));
            }
        }
        return voices;
    }

    private static Voice makeVoice(String name, Locale locale) {
        return new Voice(name, locale, Voice.QUALITY_NORMAL, Voice.LATENCY_NORMAL, false, new HashSet<String>());
    }

    @Override
    public String onGetDefaultVoiceNameFor(String lang, String country, String variant) {
        String k = Langs.key(lang);
        if ("hi".equals(k)) return "hi-in-dual";
        if ("en".equals(k)) {
            if ("GBR".equals(country)) return "en-gb-dual";
            if ("IND".equals(country)) return "en-in-dual";
            return "en-us-dual";
        }
        if (k == null || k.isEmpty()) return "en-us-dual";
        return k + "-dual";
    }

    private static boolean isOurVoice(String voiceName) {
        return voiceName != null && voiceName.length() >= 6 && voiceName.endsWith("-dual");
    }

    @Override
    public int onIsValidVoiceName(String voiceName) {
        return isOurVoice(voiceName) ? TextToSpeech.SUCCESS : TextToSpeech.ERROR;
    }

    @Override
    public int onLoadVoice(String voiceName) {
        return onIsValidVoiceName(voiceName);
    }

    @Override
    protected void onStop() {
        stopRequested = true;
        for (Backend b : allBackends()) {
            try { if (b.tts != null) b.tts.stop(); } catch (Exception ignored) { }
        }
        CountDownLatch waiting = currentSynthLatch;
        if (waiting != null) waiting.countDown();
    }

    // ---------- backend engine management (backendThread only) ----------
    private void connectOnBackendThread(Backend b) {
        String wanted = prefs.getString(b.key + "_engine", FALLBACK_ENGINE);
        // Never use ourselves as our own backend (infinite loop / hang).
        if (wanted == null || wanted.isEmpty() || wanted.equals(getPackageName())) wanted = FALLBACK_ENGINE;

        if (b.tts != null && wanted.equals(b.engine)
                && (b.ready || b.readyLatch.getCount() > 0)) {
            return; // already connected (or still connecting) to the right engine
        }
        if (b.tts != null) {
            try { b.tts.shutdown(); } catch (Exception ignored) { }
        }

        final CountDownLatch latch = new CountDownLatch(1);
        final Backend fb = b;
        b.readyLatch = latch;
        b.ready = false;
        b.engine = wanted;
        b.voice = null;
        b.rate = -1f;
        b.pitch = -1f;
        b.tts = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS && fb.readyLatch == latch) fb.ready = true;
            latch.countDown();
        }, wanted);
    }

    // Applies the saved voice / speed / pitch if they changed since last time.
    private void applySettingsOnBackendThread(Backend b) {
        if (b.tts == null || !b.ready) return;
        try {
            String v = prefs.getString(b.key + "_voice", "");
            if (v == null) v = "";
            String tag = prefs.getString(b.key + "_locale", "");
            if (tag == null) tag = "";
            String sig = v + "|" + tag;
            if (!sig.equals(b.voice)) {
                boolean set = false;
                if (!v.isEmpty()) {
                    Set<Voice> all = b.tts.getVoices();
                    if (all != null) {
                        for (Voice x : all) {
                            if (v.equals(x.getName())) {
                                b.tts.setVoice(x);
                                set = true;
                                break;
                            }
                        }
                    }
                }
                if (!set) {
                    Locale loc = tag.isEmpty() ? Langs.defaultLocale(b.key) : Locale.forLanguageTag(tag);
                    b.tts.setLanguage(loc);
                }
                b.voice = sig;
            }
            float speed = prefs.getFloat(b.key + "_speed", 1f);
            if (speed != b.rate) {
                b.tts.setSpeechRate(speed);
                b.rate = speed;
            }
            float pitch = prefs.getFloat(b.key + "_pitch", 1f);
            if (pitch != b.pitch) {
                b.tts.setPitch(pitch);
                b.pitch = pitch;
            }
        } catch (Exception ignored) { }
    }

    // ---------- called from the synthesis thread ----------
    private TextToSpeech prepare(final Backend b) {
        final CountDownLatch connected = new CountDownLatch(1);
        backendHandler.post(() -> {
            try { connectOnBackendThread(b); } catch (Exception ignored) { }
            connected.countDown();
        });
        try { connected.await(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }

        try { b.readyLatch.await(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
        if (!b.ready || b.tts == null) return null;

        final CountDownLatch applied = new CountDownLatch(1);
        backendHandler.post(() -> {
            applySettingsOnBackendThread(b);
            applied.countDown();
        });
        try { applied.await(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
        return b.tts;
    }

    // ---------- the main entry point Android calls to speak text ----------
    @Override
    protected void onSynthesizeText(SynthesisRequest request, SynthesisCallback callback) {
        stopRequested = false;
        long startTime = SystemClock.elapsedRealtime();
        String text = request.getCharSequenceText() != null
                ? request.getCharSequenceText().toString()
                : request.getText();
        if (text == null) text = "";

        boolean started = false;
        try {
            for (String[] run : splitByScript(text)) {
                if (stopRequested) break;
                if (SystemClock.elapsedRealtime() - startTime > MAX_TOTAL_SYNTH_MS) break;

                String chunkText = run[0];
                if (chunkText.trim().isEmpty()) continue;
                Backend b = getBackend(run[1]);

                TextToSpeech engine = prepare(b);
                if (engine == null) continue;

                PcmAudio pcm = synthesizeChunkBlocking(engine, chunkText, CHUNK_SYNTH_TIMEOUT_MS);
                if (pcm == null || pcm.samples == null || pcm.samples.length == 0) continue;

                short[] audio = resampleToTarget(pcm.samples, pcm.sampleRate, pcm.channels);
                audio = applyGain(audio, b);

                if (!started) {
                    callback.start(TARGET_SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1);
                    started = true;
                }
                writeShortsToCallback(callback, audio);
            }
        } catch (Exception e) {
            if (!started) callback.start(TARGET_SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1);
            callback.error();
            return;
        }

        if (!started) callback.start(TARGET_SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1);
        callback.done();
    }

    // Per-language volume. With "override" on, the sound is boosted a lot more
    // and soft-clipped: always loud, even if the quality suffers.
    private short[] applyGain(short[] in, Backend b) {
        float vol = prefs.getFloat(b.key + "_volume", 1f);
        boolean boost = prefs.getBoolean(b.key + "_boost", false);
        if (!boost && Math.abs(vol - 1f) < 0.01f) return in;
        float g = boost ? vol * 3f : vol;
        short[] out = new short[in.length];
        for (int i = 0; i < in.length; i++) {
            float x = (in[i] / 32768f) * g;
            if (boost) x = (float) Math.tanh(x);
            if (x > 1f) x = 1f;
            if (x < -1f) x = -1f;
            out[i] = (short) (x * 32767f);
        }
        return out;
    }

    private void writeShortsToCallback(SynthesisCallback callback, short[] samples) {
        int maxBytes = callback.getMaxBufferSize();
        byte[] buffer = new byte[samples.length * 2];
        for (int i = 0; i < samples.length; i++) {
            buffer[i * 2] = (byte) (samples[i] & 0xFF);
            buffer[i * 2 + 1] = (byte) ((samples[i] >> 8) & 0xFF);
        }
        int offset = 0;
        while (offset < buffer.length && !stopRequested) {
            int len = Math.min(maxBytes, buffer.length - offset);
            callback.audioAvailable(buffer, offset, len);
            offset += len;
        }
    }

    // ---------- split text into runs of one language (by script) ----------
    // Digits, spaces and punctuation stay with the text around them.
    private List<String[]> splitByScript(String text) {
        List<String[]> runs = new ArrayList<>();
        if (text.isEmpty()) return runs;
        StringBuilder buf = new StringBuilder();
        String cur = null;
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            int n = Character.charCount(cp);
            String lang = Langs.scriptLang(cp);
            if (lang != null && cur != null && !lang.equals(cur)) {
                runs.add(new String[]{buf.toString(), cur});
                buf = new StringBuilder();
            }
            if (lang != null) cur = lang;
            buf.append(text, i, i + n);
            i += n;
        }
        if (buf.length() > 0) {
            runs.add(new String[]{buf.toString(), cur != null ? cur : "en"});
        }
        return runs;
    }

    // ---------- render one chunk via the real backend engine into raw PCM ----------
    private static class PcmAudio {
        int sampleRate;
        int channels;
        short[] samples;
    }

    private PcmAudio synthesizeChunkBlocking(TextToSpeech engine, String text, long timeoutMs) {
        try {
            File outFile = File.createTempFile("dualtts_", ".wav", getCacheDir());
            String utteranceId = "chunk_" + System.nanoTime();
            CountDownLatch latch = new CountDownLatch(1);
            currentSynthLatch = latch;

            backendHandler.post(() -> {
                engine.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { if (id.equals(utteranceId)) latch.countDown(); }
                    @Override public void onError(String id) { if (id.equals(utteranceId)) latch.countDown(); }
                });
                engine.synthesizeToFile(text, null, outFile, utteranceId);
            });

            long deadline = SystemClock.elapsedRealtime() + timeoutMs;
            boolean finished = false;
            while (SystemClock.elapsedRealtime() < deadline) {
                if (stopRequested) break;
                finished = latch.await(100, TimeUnit.MILLISECONDS);
                if (finished) break;
            }

            if (!finished) {
                outFile.delete();
                return null;
            }

            PcmAudio result = readWav(outFile);
            outFile.delete();
            return result;
        } catch (Exception e) {
            return null;
        } finally {
            currentSynthLatch = null;
        }
    }

    private PcmAudio readWav(File file) throws Exception {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] header = new byte[44];
            raf.readFully(header);
            int channels = (header[22] & 0xFF) | ((header[23] & 0xFF) << 8);
            int sampleRate = (header[24] & 0xFF) | ((header[25] & 0xFF) << 8)
                    | ((header[26] & 0xFF) << 16) | ((header[27] & 0xFF) << 24);
            long dataLen = raf.length() - 44;
            byte[] data = new byte[(int) dataLen];
            raf.readFully(data);

            short[] samples = new short[data.length / 2];
            for (int i = 0; i < samples.length; i++) {
                samples[i] = (short) ((data[i * 2] & 0xFF) | (data[i * 2 + 1] << 8));
            }
            PcmAudio pcm = new PcmAudio();
            pcm.sampleRate = sampleRate > 0 ? sampleRate : TARGET_SAMPLE_RATE;
            pcm.channels = channels > 0 ? channels : 1;
            pcm.samples = samples;
            return pcm;
        }
    }

    // ---------- linear-interpolation resample + downmix so all chunks share one format ----------
    private short[] resampleToTarget(short[] input, int sourceRate, int channels) {
        short[] mono;
        if (channels > 1) {
            mono = new short[input.length / channels];
            for (int i = 0; i < mono.length; i++) {
                int sum = 0;
                for (int c = 0; c < channels; c++) sum += input[i * channels + c];
                mono[i] = (short) (sum / channels);
            }
        } else {
            mono = input;
        }

        if (sourceRate == TARGET_SAMPLE_RATE || mono.length == 0) return mono;

        double ratio = (double) sourceRate / (double) TARGET_SAMPLE_RATE;
        int outLen = (int) (mono.length / ratio);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            double srcPos = i * ratio;
            int idx = (int) srcPos;
            double frac = srcPos - idx;
            short a = mono[Math.min(idx, mono.length - 1)];
            short b2 = mono[Math.min(idx + 1, mono.length - 1)];
            out[i] = (short) (a + (b2 - a) * frac);
        }
        return out;
    }
}
