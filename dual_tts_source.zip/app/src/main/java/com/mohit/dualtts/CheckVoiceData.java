package com.mohit.dualtts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

// Invisible activity: Settings > Text-to-speech launches this for the active
// engine and waits for setResult(). It must answer instantly and finish.
public class CheckVoiceData extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ArrayList<String> available = new ArrayList<>();
        available.add("hin-IND");
        available.add("eng-USA");
        available.add("eng-GBR");
        available.add("eng-IND");
        Intent result = new Intent();
        result.putStringArrayListExtra("availableVoices", available);
        result.putStringArrayListExtra("unavailableVoices", new ArrayList<String>());
        setResult(1, result); // 1 = CHECK_VOICE_DATA_PASS
        finish();
    }
}
