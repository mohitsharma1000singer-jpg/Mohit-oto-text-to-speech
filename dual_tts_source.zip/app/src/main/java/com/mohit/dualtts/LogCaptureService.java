package com.mohit.dualtts;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayDeque;

// Runs "logcat" continuously in the background and keeps appending it to a
// file, so a freeze/crash that happens WHILE the user is away from our app
// (e.g. inside Settings) is already captured by the time they come back --
// no need to react within a fixed time window.
public class LogCaptureService extends Service {

    private static final String CHANNEL_ID = "log_capture_channel";
    private static final int NOTIF_ID = 1001;
    private static final int MAX_LINES = 8000;
    private static final long MAX_DURATION_MS = 10 * 60 * 1000; // auto-stop after 10 minutes

    private Thread captureThread;
    private volatile boolean running = false;
    private Process logcatProcess;

    public static final String LOG_FILE_NAME = "system_log_capture.txt";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_STICKY;
        running = true;

        createNotificationChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("सिस्टम लॉग रिकॉर्ड हो रहा है")
                .setContentText("Pocket Dual TTS जांच के लिए लॉग इकट्ठा कर रहा है")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .build();
        startForeground(NOTIF_ID, notification);

        File outFile = new File(getFilesDir(), LOG_FILE_NAME);

        captureThread = new Thread(() -> {
            try {
                logcatProcess = Runtime.getRuntime().exec(new String[]{
                        "logcat", "-b", "main", "-b", "system", "-b", "crash", "-b", "events", "-v", "time"});
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(logcatProcess.getInputStream()));
                ArrayDeque<String> lines = new ArrayDeque<>();
                String line;
                while (running && (line = reader.readLine()) != null) {
                    lines.add(line);
                    if (lines.size() > MAX_LINES) lines.removeFirst();
                    // flush to disk periodically so data survives even if the
                    // service later gets killed before a clean stop
                    if (lines.size() % 200 == 0) writeLinesToFile(outFile, lines);
                }
                writeLinesToFile(outFile, lines);
            } catch (Exception e) {
                CrashLogger.log(LogCaptureService.this, "LOGCAPTURE-ERROR", String.valueOf(e));
            }
        });
        captureThread.start();

        // safety auto-stop so this never runs forever draining battery
        new Handler(Looper.getMainLooper()).postDelayed(this::stopCapture, MAX_DURATION_MS);

        return START_STICKY;
    }

    private void writeLinesToFile(File outFile, ArrayDeque<String> lines) {
        try (FileWriter fw = new FileWriter(outFile, false)) {
            for (String l : lines) {
                fw.write(l);
                fw.write("\n");
            }
        } catch (Exception ignored) {
        }
    }

    private void stopCapture() {
        running = false;
        if (logcatProcess != null) logcatProcess.destroy();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        stopCapture();
        super.onDestroy();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Log Capture", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
