package com.mohit.dualtts;

import android.content.Context;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

// Records crashes AND a lightweight activity timeline (what happened, when --
// never the actual text being spoken, since this engine sees everything
// typed system-wide and that could include passwords or private messages).
// Readable/shareable later without needing a computer or ADB.
public class CrashLogger {

    private static boolean installed = false;
    private static final int MAX_LOG_CHARS = 20000; // keep the file from growing forever

    public static synchronized void install(Context appContext) {
        if (installed) return;
        installed = true;

        Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Context ctx = appContext.getApplicationContext();

        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                StringWriter sw = new StringWriter();
                throwable.printStackTrace(new PrintWriter(sw));
                appendLine(ctx, "CRASH", "Thread: " + thread.getName() + "\n" + sw);
            } catch (Exception ignored) {
                // never let logging itself cause a second crash
            }
            if (previous != null) {
                previous.uncaughtException(thread, throwable);
            }
        });
    }

    // tag: short category like "SERVICE", "HINDI-CONNECT", "SYNTH". message:
    // safe metadata only -- never the spoken/typed text itself.
    public static synchronized void log(Context context, String tag, String message) {
        appendLine(context.getApplicationContext(), tag, message);
    }

    private static void appendLine(Context ctx, String tag, String message) {
        try {
            File logFile = new File(ctx.getFilesDir(), "crash_log.txt");
            String timestamp = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
            try (FileWriter fw = new FileWriter(logFile, true)) {
                fw.write("[" + timestamp + "] " + tag + ": " + message + "\n");
            }
            trimIfTooLarge(logFile);
        } catch (Exception ignored) { }
    }

    private static void trimIfTooLarge(File logFile) {
        try {
            if (logFile.length() > MAX_LOG_CHARS * 2L) {
                String content = readFile(logFile);
                if (content.length() > MAX_LOG_CHARS) {
                    content = "...(पुराना हिस्सा हटाया गया)...\n" + content.substring(content.length() - MAX_LOG_CHARS);
                    try (FileWriter fw = new FileWriter(logFile, false)) {
                        fw.write(content);
                    }
                }
            }
        } catch (Exception ignored) { }
    }

    private static String readFile(File f) throws Exception {
        java.io.FileInputStream fis = new java.io.FileInputStream(f);
        byte[] data = new byte[(int) f.length()];
        fis.read(data);
        fis.close();
        return new String(data, "UTF-8");
    }

    public static String readLog(Context context) {
        try {
            File logFile = new File(context.getFilesDir(), "crash_log.txt");
            if (!logFile.exists()) return "अभी तक कोई लॉग रिकॉर्ड नहीं हुआ है।";
            return readFile(logFile);
        } catch (Exception e) {
            return "लॉग पढ़ने में समस्या: " + e.getMessage();
        }
    }

    public static void clearLog(Context context) {
        File logFile = new File(context.getFilesDir(), "crash_log.txt");
        if (logFile.exists()) logFile.delete();
    }
}
